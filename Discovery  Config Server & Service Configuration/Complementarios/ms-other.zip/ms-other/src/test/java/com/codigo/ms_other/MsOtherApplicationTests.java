package com.codigo.ms_other;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOtherApplicationTests {

	@Test
	void contextLoads() {
	}

}
